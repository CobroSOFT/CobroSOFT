@echo off
@echo off
ren instalador_cobrosoft.stp instalador_cobroSOFT.exe
instalador_cobroSOFT.exe
